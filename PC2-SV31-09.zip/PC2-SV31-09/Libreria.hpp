#include <string>
#include <vector>
#include <fstream>
#include <list>
#include <sstream>
#include <iostream>
#include <functional>
#include <iterator>
#include <stack>//pilas
#include <queue>//colas
#include <algorithm>//Algoritmos-->sort /copy
#include <functional>
#include <windows.h>


using namespace std;